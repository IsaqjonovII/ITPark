import{j as s}from"./index-b4e51de9.js";const r=()=>s.jsx("div",{children:"News"});export{r as default};
