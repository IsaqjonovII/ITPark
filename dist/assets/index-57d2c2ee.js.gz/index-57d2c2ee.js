import{j as t}from"./index-deecd7ee.js";const s=()=>t.jsx("div",{});export{s as default};
