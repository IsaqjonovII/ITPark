import{j as t}from"./index-ba88aa81.js";const r=()=>t.jsx("div",{});export{r as default};
