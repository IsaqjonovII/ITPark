import{j as t}from"./index-8066d643.js";const o=()=>t.jsx("div",{children:"StartupInfo"});export{o as default};
