import{j as t}from"./index-b4e51de9.js";const o=()=>t.jsx("div",{children:"StartupInfo"});export{o as default};
