import{j as t}from"./index-b4e51de9.js";const s=()=>t.jsx("div",{});export{s as default};
