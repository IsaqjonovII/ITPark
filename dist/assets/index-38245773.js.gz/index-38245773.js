import{j as t}from"./index-daa35007.js";const o=()=>t.jsx("div",{children:"StartupInfo"});export{o as default};
