import{j as t}from"./index-deecd7ee.js";const o=()=>t.jsx("div",{children:"StartupInfo"});export{o as default};
