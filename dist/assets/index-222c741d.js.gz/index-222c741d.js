import{j as t}from"./index-daa35007.js";const s=()=>t.jsx("div",{});export{s as default};
