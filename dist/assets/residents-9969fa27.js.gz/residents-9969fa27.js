const s="/assets/residents-655538c4.svg";export{s as r};
