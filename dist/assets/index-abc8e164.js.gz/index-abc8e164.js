import{j as t}from"./index-ba88aa81.js";const o=()=>t.jsx("div",{children:"StartupInfo"});export{o as default};
