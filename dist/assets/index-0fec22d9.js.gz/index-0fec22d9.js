import{s as t,j as o}from"./index-ba88aa81.js";const n="/assets/notfound-dd9d0ddf.svg",e=t.div`
  width: 100%;
  height: calc(100vh - 5rem);
  background-image: url(${n});
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center;
`,d=()=>o.jsx(e,{});export{d as default};
