import{j as t}from"./index-8066d643.js";const s=()=>t.jsx("div",{});export{s as default};
